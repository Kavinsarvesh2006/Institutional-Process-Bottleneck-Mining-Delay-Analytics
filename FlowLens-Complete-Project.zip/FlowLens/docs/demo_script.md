# Five-minute demonstration

Before the viva: run `py -3 run.py setup` once, then `py -3 run.py demo`. Keep the terminal open. Select the Campus operations sample and clear all filters. Use elapsed-hour settings and default weights/SLA values so the reference figures match.

## 00:00–00:40 · The problem and evidence

Open Overview: “Institutions see final approvals, but often cannot see the waiting between steps. FlowLens reconstructs that waiting from event logs.” Point to 3,200 cases and 14,692 accepted events. Explain that data is synthetic and reproducible. Mention 87.7h mean cycle and 15.4% closed-case SLA breach rate.

## 00:40–01:30 · Discover the actual process

Open Process map. Select Fee Receipt to expose the Office → Student Correction → Office loop. Click Office Processing and inspect queue distribution. Explain edge frequency and receiving-step waits. Select Bonafide Certificate, overlay the ideal path, then reset All workflows.

## 01:30–02:15 · Locate the bottleneck

Open Bottlenecks. Principal Approval averages 90h queue, HOD 43.6h. Explain mean vs P90 and weighted, normalised scoring. Switch to resource grouping, inspect an office clerk and show the service comparison. Clarify that Clerk B's planted effect is service duration, distinct from incoming queue time.

## 02:15–03:00 · Explain delays and individual cases

Open Delay analytics: show the seven-day trend increase, percentile tail, heatmap and association lift table. “These are associations, not causal judgements.” Open Case explorer and search `BON-2026-0001`; show service vs queue segments and the SLA marker.

## 03:00–04:00 · Predict and simulate

Open Predict & simulate. Submit Bonafide Certificate, AI & DS, Monday, 8h first queue. The model returns a moderate risk estimate. Show chronological holdout metrics and state that 81.1% accuracy equals the majority baseline; precision and recall therefore matter. Run Principal Approval at 50% queue reduction: mean cycle about 69.6h, breach about 7.8%, 235 breaches avoided. “This holds all other durations fixed.”

## 04:00–04:35 · Turn insight into action

Open Recommendations and show the top signing-window intervention, evidence and simulated impact. Export the PDF; show charts and action evidence. Do not add savings across action cards because the same cases can overlap.

## 04:35–05:00 · Reproducibility and configuration

Open Data & settings. Show the CSV template, import audit, SLA/ideal-path editor, weights, holiday calendar and pseudonyms. Mention all five planted patterns are rediscovered by a quantitative test and service coverage exceeds 80%. Show light/dark mode if time permits.

Backup demo: the included `docs/sample-report.pdf` and screenshots work without launching the app. For a malformed CSV demonstration, upload `backend/tests/fixtures/malformed.csv`; it produces a quality receipt without crashing or changing the active dataset.
